package com.dra.vision.component;

public class EyedeaDef {
	public class VisionConfigOption
	{
		public static final int VISION_CONFIG_CALIBRATION_CHESS_NUM_COLS = 101;
		public static final int VISION_CONFIG_CALIBRATION_CHESS_NUM_ROWS = 102;
		public static final int VISION_CONFIG_CALIBRATION_CHESS_SIZE = 103;
		public static final int VISION_CONFIG_BLUR = 104;
		public static final int VISION_CONFIG_DENOISING = 105;
		public static final int VISION_CONFIG_EDGE_LOW_THRESHOLD = 106;
		public static final int VISION_CONFIG_EDGE_MAX_LOW_THRESHOLD = 107;
		public static final int VISION_CONFIG_EDGE_KERNEL_SIZE = 108;
		public static final int VISION_CONFIG_MATCHING_THRESHOLD = 109;
		public static final int VISION_CONFIG_CIRCLE_DETECTION_INLIER_RATE = 110;
		public static final int VISION_CONFIG_CIRCLE_DETECTION_MAX_ITERATION = 111;
		public static final int VISION_CONFIG_L_MIN_ANGLE = 112;
		public static final int VISION_CONFIG_L_MAX_ANGLE = 113;
		public static final int VISION_CONFIG_EDGE_MATCHING_MARGIN = 114;
		public static final int VISION_CONFIG_FIND_OBJECT_MASKING_OPTION = 115;
		public static final int VISION_CONFIG_FIND_OBJECT_MASKING_OPTION_THRESHOLD = 116;
		public static final int VISION_CONFIG_USE_CONVEXHULL = 117;
		public static final int VISION_CONFIG_USE_BGSUB = 118;
		public static final int VISION_CONFIG_ONLY_ONE_OBJECT = 119; 
		public static final int VISION_CONFIG_FIND_OBJECT_LEVEL = 120;
		public static final int VISION_CONFIG_USE_CALIBRATION_IMAGE = 121;
		public static final int VISION_CONFIG_USE_HISTOGRAM = 122;
		public static final int VISION_CONFIG_IMAGE_MORPH_SIZE = 123;
		public static final int VISION_CONFIG_POSITIVE_RATE = 124;
		public static final int VISION_CONFIG_FIND_ONE_OF_SUBS = 125;
	}

	public class GetImageOption
	{
		public static final int GET_IMAGE_INPUT = 201;
		public static final int GET_IMAGE_BASE = 202;
		public static final int GET_IMAGE_BASE_WITH_INFO = 203;
		public static final int GET_IMAGE_BASE_ROI = 204;
		public static final int GET_IMAGE_CALIBRATION_FEATURE = 205;
		public static final int GET_IMAGE_BASE_HISTORY_MASK = 206;
	};

	class DrawResultOption
	{
		public static final int RESULT_DRAW_OPTION_SEARCH_FEAT	= 0x0001;
		public static final int RESULT_DRAW_OPTION_SEARCH_BOX	= 0x0002;
		public static final int RESULT_DRAW_OPTION_SEARCH_ARROW	= 0x0004;
		public static final int RESULT_DRAW_OPTION_MASTER_FEAT	= 0x0008;
		public static final int RESULT_DRAW_OPTION_MASTER_BOX	= 0x0010;
		public static final int RESULT_DRAW_OPTION_MASTER_TEXT	= 0x0020;
		public static final int RESULT_DRAW_OPTION_OBJECT		= 0x0040;
		public static final int RESULT_DRAW_OPTION_OBJECT_TEXT	= 0x0080;
		public static final int WITH_DRAW_OPTION_FEATURE		= 0x0100;
		public static final int WITH_DRAW_SEARCH_AREA_RANGE		= 0x0200;
		public static final int RESULT_DRAW_OPTION_ALL = 0xFFFF;
	};

	class SetCameraConfigOption
	{
		public static final int SET_CAMERA_AUTO_EXPOSURE = 701;
		public static final int SET_CAMERA_AUTO_EXPOSURE_RANGE_GO_OUT = 702;
		public static final int SET_CAMERA_AUTO_EXPOSURE_RANGE_ENTER = 703;
		public static final int SET_CAMERA_MANUAL_EXPOSURE = 704;
		public static final int SET_CAMERA_MANUAL_EXPOSURE_EXPOSURE = 705;
		public static final int SET_CAMERA_MANUAL_EXPOSURE_GAIN = 706;
		public static final int SET_CAMERA_TAKE_PIC = 707;
		public static final int SET_CAMERA_LED_BRIGHTNESS = 708;
		public static final int SET_CAMERA_LED_TIMER_ON = 709;
	};
	
	class GetCameraConfigOption
	{
		public static final int GET_CAMERA_AUTO_EXPOSURE = 801;
		public static final int GET_CAMERA_AUTO_EXPOSURE_RANGE_GO_OUT = 802;
		public static final int GET_CAMERA_AUTO_EXPOSURE_RANGE_ENTER = 803;
		public static final int GET_CAMERA_MANUAL_EXPOSURE = 804;
		public static final int GET_CAMERA_MANUAL_EXPOSURE_EXPOSURE = 805;
		public static final int GET_CAMERA_MANUAL_EXPOSURE_GAIN = 806;
		public static final int GET_CAMERA_LED_BRIGHTNESS = 807;
	};

	class HistogramUseOption
	{
		public static final int HISTOGRAM_USE_GRAY = 0x0001;
		public static final int HISTOGRAM_USE_RED = 0x0002;
		public static final int HISTOGRAM_USE_GREEN = 0x0004;
		public static final int HISTOGRAM_USE_BLUE = 0x0008;
		public static final int HISTOGRAM_USE_ALL = 0xFFFF;
	};
	
}
