package com.dra.vision.component;

public class ERVS_JNI {
	
	static {
    	System.loadLibrary("ERVS");
    }
	
	//Server Connect
	public native static int ERVS_Connect(byte[] ip, int port);
	public native static void ERVS_Disconnect();
	
	//System
	public native static String ERVS_GetVersion();
	public native static int ERVS_SetNextImage();
	
	//Get Image from ERVS to Client
	public native static int ERVS_GetImage(int option, int option2, byte[] data, int[] len);
	public native static int ERVS_GetFindObjectResultImage(int option, int option2, byte[] data, int[] len);
	
	//Job Management
	public native static int ERVS_DBAddObject();
	public native static int ERVS_DB_Get_Count();
	public native static int ERVS_DB_Get_Info_Id(int index);
	public native static int ERVS_DB_Get_Select_ID();
	public native static int ERVS_DB_Del_ID(int id);
	public native static String ERVS_DB_Get_Mode(int id);
	public native static int ERVS_SetObject(int id);
	
	public native static int ERVS_SetJobName(int id, String name);
	public native static String ERVS_GetJobName(int id);
	public native static int ERVS_SetToolName(int id, String name);
	public native static String ERVS_GetToolName(int id);
	public native static int ERVS_SetToolType(int id, int type);
	public native static int ERVS_GetToolType(int id);
	public native static int ERVS_SetToolState(int id, int state);
	public native static int ERVS_GetToolState(int id);
	public native static int ERVS_SetRobotPose(int id, double[] posj, int posj_size);
	public native static double[] ERVS_GetRobotPose(int id, int[] posj_size);
	
	//DB Save/Load
	public native static int ERVS_FileSaveObjectDBList(String path);
	public native static int ERVS_FileLoadObjectDBList(String path);
		
	//Option
	public native static int ERVS_OptionFixAreaOn();
	public native static int ERVS_OptionFixAreaOff();
	public native static int ERVS_GetOptionFixArea();
	
	//Zoom
	public native static int ERVS_SetZoomArea(float x, float y, float w, float h);
	public native static int ERVS_ResetZoomArea();
	
	//Mask Area
	public native static int ERVS_SetMaskArea(float x, float y, float w, float h, boolean inverse);
	public native static int ERVS_UndoMaskArea();
	public native static int ERVS_DelMaskArea();
	
	//Vision Config Option
	public native static int ERVS_SetVisionConfigOption(int option, float value);
	public native static float ERVS_GetVisionConfigOption(int option);
	
	//Set Job
	public native static int ERVS_SetBase(int dep_id);
	//Circle Object
	public native static int ERVS_SetObjectCircle(float x, float y, float r1, float r2);
	public native static int ERVS_SetObjectCircle(float x, float y, float r1, float r2, float min_r1, float min_r2, float max_r1, float max_r2);
	public native static int ERVS_SetObjectCircleBaseDiameter(int id, int diameter);
	public native static int ERVS_GetObjectCircleBaseDiameter(int id);
	public native static int ERVS_SetObjectCircleDiameterTolerance(int id, int min_value, int max_value);
	public native static int ERVS_GetObjectCircleDiameterTolerance(int id, int[] out_min_value, int[] out_max_value);
	public native static int ERVS_SetObjectCircleDiameterInspection(int id, boolean use);
	public native static int ERVS_GetObjectCircleDiameterInspection(int id);
	public native static float ERVS_GetObjectCircleCalcDiameter(int id);
	public native static int ERVS_GetObjectCircle(float[] out_x, float[] out_y, float[] out_r1, float[] out_r2);

	//Line Object
	public native static int ERVS_SetObjectLine(float x, float y, float w, float h);
	public native static int ERVS_DelObjectLine();
	public native static int ERVS_ClrObjectLine();
	public native static int ERVS_SetObjectTwoLine(int id, float x1, float y1, float w1, float h1, float x2, float y2, float w2, float h2);
	//Two Line Distance
	public native static int ERVS_SetObjectTwoLineBaseDistance(int id, int dist);
	public native static int ERVS_GetObjectTwoLineBaseDistance(int id);
	public native static float ERVS_GetObjectTwoLineCalcDistance(int id);
	public native static int ERVS_SetObjectTwoLineDistanceTolerance(int id, int min_value, int max_value);
	public native static int ERVS_GetObjectTwoLineDistanceTolerance(int id, int[] out_min_value, int[] out_max_value);
	public native static int ERVS_SetObjectTwoLineDistanceType(int id, int type);
	public native static int ERVS_GetObjectTwoLineDistanceType(int id);
	public native static int ERVS_SetObjectTwoLineDistanceInspection(int id, boolean use);
	public native static int ERVS_GetObjectTwoLineDistanceInspection(int id);
	//Two Line Angle
	public native static int ERVS_SetObjectTwoLineBaseAngle(int id, int angle);
	public native static int ERVS_GetObjectTwoLineBaseAngle(int id);
	public native static float ERVS_GetObjectTwoLineCalcAngle(int id);
	public native static int ERVS_SetObjectTwoLineAngleTolerance(int id, int min_value, int max_value);
	public native static int ERVS_GetObjectTwoLineAngleTolerance(int id, int[] out_min_value, int[] out_max_value);
	public native static int ERVS_SetObjectTwoLineAngleInspection(int id, boolean use);
	public native static int ERVS_GetObjectTwoLineAngleInspection(int id);
	
	//Region Object
	public native static int ERVS_SetSelectBaseObject(float x, float y, float w, float h);
	
	//Detect
	public native static int ERVS_DetectWithGrab(int index, int max_objects_count, float[] out_id, float[] out_cx, float[] out_cy, float[] out_rx, float[] out_ry, float[] out_bound_cx, float[] out_bound_cy, float[] out_bound_rx, float[] out_bound_ry, float[] out_mass_cx, float[] out_mass_cy, float[] out_mass_rx, float[] out_mass_ry, float[] out_circle_rx, float[] out_circle_ry, float[] out_line1_x, float[] out_line1_y, float[] out_line2_x, float[] out_line2_y, float[] out_angle, float[] out_type, float[] out_score, float[] out_pass);
	public native static int ERVS_DetectWithGrab(int index, int max_objects_count, float[] out_id, 
			float[] out_cx, float[] out_cy, float[] out_rx, float[] out_ry, 
			float[] out_bound_cx, float[] out_bound_cy, float[] out_bound_rx, float[] out_bound_ry, 
			float[] out_mass_cx, float[] out_mass_cy, float[] out_mass_rx, float[] out_mass_ry, 
			float[] out_circle_rx, float[] out_circle_ry, float[] out_circle_diameter, float[] out_circle_pass, 
			float[] out_line_distance, float[] out_line_distance_pass,
			float[] out_line_angle, float[] out_line_angle_pass,
			float[] out_histogram, float[] out_histogram_pass,
			float[] out_angle, float[] out_type, float[] out_score);
	public native static int ERVS_DetectWithPrevImage(int index, int max_objects_count, float[] out_id, float[] out_cx, float[] out_cy, float[] out_rx, float[] out_ry, float[] out_bound_cx, float[] out_bound_cy, float[] out_bound_rx, float[] out_bound_ry, float[] out_mass_cx, float[] out_mass_cy, float[] out_mass_rx, float[] out_mass_ry, float[] out_circle_rx, float[] out_circle_ry, float[] out_line1_x, float[] out_line1_y, float[] out_line2_x, float[] out_line2_y, float[] out_angle, float[] out_type, float[] out_score, float[] out_pass);
	//Detect Result
	public native static int ERVS_GetFindObjectResultInfo(int base_index, int sub_index,float[] out_id, float[] out_cx, float[] out_cy, float[] out_rx, float[] out_ry, float[] out_angle, float[] out_type, float[] out_score, float[] out_histogram, float[] out_histogram_b, float[] out_histogram_g, float[] out_histogram_r, float[] out_histogram_size);

	//Calibration
	public native static int ERVS_Calibration_Add(float robot_x, float robot_y);
	public native static int ERVS_Calibration_GetCount();
	public native static int ERVS_Calibration_GetImage(int index, byte[] data, int[] len);
	public native static int ERVS_Calibration_GetRobotInfo(int index, float[] out_robot_x, float[] out_robot_y);
	public native static int ERVS_Calibration_Del(int index);
	public native static int ERVS_Calibration_Clear();
	public native static int ERVS_Calibration_Run();
	public native static int ERVS_Calibration_GetPoint(float in_px, float in_py, float[] out_rx, float[] out_ry);
	public native static int ERVS_Calibration_GetChessPoint(int index, float[] out_rx, float[] out_ry);
	public native static int ERVS_Calibration_isOK();
	public native static int ERVS_Calibration_Save();
	public native static int ERVS_Calibration_Load();
	public native static int ERVS_Calibration_Copy(int id);
	public native static int ERVS_Calibration_GetID();
	
	
	//Camera Setting
	public native static int ERVS_SetCameraConfig(int type, int value, int value2);
	public native static int ERVS_GetCameraConfig(int type);
	public native static int ERVS_SetCameraConfig_Default();
	public native static int ERVS_SetCameraConfig_Save();
	public native static int ERVS_SetCameraConfig_Load();

	//Background Learning
	public native static int ERVS_BackgroundLearning();
	
	//Geometry
	public native static int ERVS_Geometry_Get_Distance(int base_id, int target_id, float []out_value);
	public native static int ERVS_Geometry_Set_Inspection_Distance(int base_id, int target_id, float value);
	public native static int ERVS_Geometry_Get_Inspection_Distance(int base_id, int target_id, float[]  out_value);
	public native static int ERVS_Geometry_Set_Inspection_Distance_Tolerance_Rate(int base_id, int target_id, float value);
	public native static int ERVS_Geometry_Get_Inspection_Distance_Tolerance_Rate(int base_id, int target_id, float[] out_value);
	public native static int ERVS_Geometry_Get_Angle(int base_id, int target_id, float []out_value);
	public native static int ERVS_Geometry_Set_Inspection_Angle(int base_id, int target_id, float value);
	public native static int ERVS_Geometry_Get_Inspection_Angle(int base_id, int target_id, float[] out_value);
	public native static int ERVS_Geometry_Set_Inspection_Angle_Tolerance_Rate(int base_id, int target_id, float value);
	public native static int ERVS_Geometry_Get_Inspection_Angle_Tolerance_Rate(int base_id, int target_id, float[] out_value);
	public native static int ERVS_Geometry_Distance(int base_id, int target_id, float[] out_value, int[] out_pass);
	public native static int ERVS_Geometry_Angle(int base_id, int target_id, float[] out_value, int[] out_pass);
	public native static int ERVS_Geometry_MeetPoint(int base_id, int target_id, float[] out_value_x, float[] out_value_y);
	public native static int ERVS_Geometry_Clear();
	
	//Histogram 
	public native static int ERVS_Histogram_Set_Range(int id, int option, int min_value, int max_value);
	public native static int ERVS_Histogram_Get_Range(int id, int option, int[] out_min_value, int[] out_max_value);
	public native static int ERVS_Histogram_Get_Graph(int id, float[] out_histogram, float[] out_histogram_b, float[] out_histogram_g, float[] out_histogram_r, float[] out_histogram_size);
	public native static int ERVS_Histogram_Set_Use_Element(int id, int option);
	public native static int ERVS_Histogram_Get_Use_Element(int id, int []out_option);
	public native static int ERVS_Histogram_Set_Inspection_Pixel_Count(int id, int count);
	public native static int ERVS_Histogram_Get_Inspection_Pixel_Count(int id, int[] out_count);
	public native static int ERVS_Histogram_Set_Inspection_Pixel_Count_Tolerance_Rate(int id, float rate);
	public native static int ERVS_Histogram_Get_Inspection_Pixel_Count_Tolerance_Rate(int id, float[] out_rate);
	public native static int ERVS_Histogram_Set_Inspection_Pixel_Count_Tolerance(int id, int min_value, int max_value);
	public native static int ERVS_Histogram_Get_Inspection_Pixel_Count_Tolerance(int id, int[] out_min_value, int[] out_max_value);
	public native static int ERVS_Histogram_Get_Pixel_Count(int id, int[] out_count);
	public native static int ERVS_Histogram_Get_Pixel_Count(int index1, int index2, int[] out_count);
	public native static int ERVS_Histogram_Set_Inspection(int id, boolean use);
	public native static int ERVS_Histogram_Get_Inspection(int id);
	
	//Image Focus Rate
	public native static int ERVS_CalcFocusRate(int id);
	public native static int ERVS_SetFocusRate(int id, int rate);
	public native static int ERVS_GetFocusRate(int id);
	//Image Contrast Rate
	public native static int ERVS_CalcContrastRate(int id);
	public native static int ERVS_SetContrastRate(int id, int rate);
	public native static int ERVS_GetContrastRate(int id);
}
